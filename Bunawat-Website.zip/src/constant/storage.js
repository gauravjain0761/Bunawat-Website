export const STORAGE_KEY = {
    token: 'token',
    user: 'user',
}

export const DEFULT_STATE = "Maharashtra"