export const API_ROUTES = {
    BASE_URL: process.env.REACT_APP_BE_URL,
    // BASE_URL: "http://192.168.1.4:3000",
    API_VERSION: '/api'
}